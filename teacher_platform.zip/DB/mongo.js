const mongoose = require('mongoose');
const mongoURI="mongodb+srv://ekshvara:Deepak%401234@cluster0.cwqbg.mongodb.net/CoinsForCollege?retryWrites=true&w=majority";

const connectToMongo=()=>{
     mongoose.connect(mongoURI,{ useNewUrlParser: true, useUnifiedTopology: true},()=>{
         console.log("Connected to MongoDB");
     })
}
module.exports = connectToMongo;