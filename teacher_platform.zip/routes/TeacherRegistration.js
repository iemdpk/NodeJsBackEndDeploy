const express = require('express')
const router = express.Router()
const teacherRegistration = require('../models/teacherRegistraton');
const { MongoClient, ServerApiVersion, Db } = require('mongodb');
const { Router } = require('express');

router.get("/create_teacher", async (req,res)=>{

  // {fname:fname,lname:lname,email:email,password:password,teacher_type:teacher_type,link:link,subject:subject,yearofExp:yearofExp,referBy:referBy}
            
          var fname = req.query.fname;
          var lname = req.query.lname;
          var email = req.query.email;
          var password = req.query.password;
          var teacher_type = req.query.teacher_type;
          var link = req.query.link;
          var subject = req.query.subject;
          var yearofExp = req.query.yearofExp;
          var referBy = req.query.referBy;
          var teacher_id= '';
          var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
          var charactersLength = characters.length;
          for ( var i = 0; i < 40; i++ ) {
          teacher_id += characters.charAt(Math.floor(Math.random() * 
charactersLength));
 }
 
    var teacherRegistration2  = new teacherRegistration({teacher_id:teacher_id,fname:fname,lname:lname,teacher_type:teacher_type,special_link:link,subject:subject,yearofExp:yearofExp,referBy:referBy,wallet:0,email:email,password:password});
     var saveTeacher = await teacherRegistration2.save();
    console.log(saveTeacher);
    await res.send(JSON.stringify(saveTeacher));
 
});

router.get("/checkAuth", async (req,res)=>{
  var lengthArray = [];
  var email = req.query.email;
  var password = req.query.password;
  teacherRegistration.findOne({email:email,password:password}, function(err, result) {
    // if(lengthArray.indexOf(result) == -1){
    //   lengthArray.push(result);
    // }
    res.send(JSON.stringify(result));
    
  });
});

module.exports = router