const express = require("express");
const router = express.Router();
const Lession = require('../models/Lession');

router.get("/runFirst",(req,res)=>{
  res.send("Working on Deepak This is WOrking on");
})

router.get("/addLession", async (req,res)=>{
    var date = req.query.date;
    var grade = req.query.grade;
    var subject = req.query.subject;
    var tags = req.query.tags;
    var topic = req.query.topic;
    var alignment = req.query.alignment;
    var title = req.query.title;
    var overview =req.query.overview;
    var content = req.query.content;
    var data = req.query.data;
    var userId = req.query.user_id;

    var lessionSave = new Lession({user_id:userId,date:date,grade:grade,subject:subject,tags:tags,topic:topic,alignment:alignment,title:title,overview:overview,content:content,data:data});

    var lessionData = await lessionSave.save();

    res.send(lessionData);
    
});

router.get("/showAllLession", async (req,res)=>{
  
  var userId = req.query.user_id;

  Lession.find({email:userId}, function(err, result) {
      res.send(JSON.stringify(result));
  });

});

module.exports = router;