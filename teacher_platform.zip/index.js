const express = require('express')
const app = express()
const port = 3003 
const connectToMongo =  require('./DB/mongo');
var cors = require('cors');
connectToMongo();
app.use(cors())
app.use('/teacher_registration', require('./routes/TeacherRegistration'))
app.use('/api/lession',require('./routes/lession'));

app.get('/', (req, res) => {
    res.send('This is Calling Server');
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})  