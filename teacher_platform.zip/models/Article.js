const mongoose = require("mongoose");
const {Schema}=mongoose;

const ArticleSchema = new Schema({
    user:{
        type: mongoose.Schema.Types.ObjectId,
        ref:"user"
    },
    type: {
        type: String,
        required: true
    },
    subject:{
        type: String,
        required: true
    },
    tags:{
        type: String,
        required: true
    },
    topic:{
        type: String,
        required: true
    },
    title:{
        type: String,
        required: true
    },
    story1:{
        type: String,
        required: true
    },
    story2:{
        type: String
    }
});
module.exports = mongoose.models['articles'] || mongoose.model('articles', ArticleSchema);