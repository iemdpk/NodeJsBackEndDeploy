const mongoose = require("mongoose");
const {Schema}=mongoose;

const LessionSchema = new Schema({
    user_id:{
        type: String,
        required: true
    },
    date:{
        type: String,
        required: true
    },
    grade:{
        type: String,
        required: true
    },
    subject:{
        type: String,
        required: true
    },
    tags: {
        type: String,
        required: true
    },
    topic:{
        type: String,
        required: true  
    },
    alignment:{
        type: String,
        required: true
    },
    title:{
        type: String,
        required: true
    },
    overview:{
        type: String,
        required: true
    },
    content:{
        type: String,
        required: true
    },
    data:{
        type: String,
        // required: true
    },
});
module.exports = mongoose.models['Lession'] || mongoose.model('Lession', LessionSchema);