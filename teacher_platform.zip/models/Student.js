const mongoose = require("mongoose");
const {Schema}=mongoose;

const StudentSchema = new Schema({
    user:{
        type: mongoose.Schema.Types.ObjectId,
        ref:"user"
    },
    name: {
        type: String,
        required: true
    },
    location:{
        type: String,
        required: true
    },
    dob:{
        type: Date,
        required: true
    },
    phone:{
        type: String,
        required: true
    },
    email:{
        type: String,
        required: true,
        unique: true
    },
    courses:{
        type: String,
        required: true
    },
    badges:{
        type: String,
        required: true
    },
    offers:{
        type: String,
        required: true
    },
    achievement:{
        type: String,
        required: true
    },
    achievementDesc:{
        type: String,
        required: true
    }
});
module.exports = mongoose.models['students'] || mongoose.model('students', StudentSchema);