const mongoose = require("mongoose");
const {Schema}=mongoose;

const SponsorshipSchema = new Schema({
    user:{
        type: mongoose.Schema.Types.ObjectId,
        ref:"user"
    },
    img:{
        data: Buffer,
        contentType: String,
        required: true
    },
    name: {
        type: String,
        required: true
    },
    reward:{
        type: String,
        required: true
    },
    date:{
        type: Date,
        default: Date.now
    },
    student:{
        type:mongoose.Schema.Types.ObjectId,
        required: true
    }
});
module.exports = mongoose.models['sponserships'] || mongoose.model('sponserships', SponsorshipSchema);