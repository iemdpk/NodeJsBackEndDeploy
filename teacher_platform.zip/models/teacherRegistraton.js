const mongoose = require("mongoose");
const {Schema}=mongoose;

const teacherRegistration = new Schema({
    teacher_id: {
        type: String,
        
    },
    fname: {
        type: String,
        
    },
    lname: {
        type: String,
        
    },
    teacher_type: {
        type: String,
        
    },
    special_link: {
        type: String,
        
    },
    subject: {
        type: String,
        
    },
    yearofExp: {
        type: String,
        
    },
    referBy: {
        type: String,
        
    },  
    wallet: {
        type: String,
        
    },  
    email:{
        type:String,
    },
    password:{
        type:String,
    }
});

module.exports = mongoose.model('teacherregistration', teacherRegistration);