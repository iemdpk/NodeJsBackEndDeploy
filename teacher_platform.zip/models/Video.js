const mongoose = require("mongoose");
const {Schema}=mongoose;

const VideoSchema = new Schema({
    user:{
        type: mongoose.Schema.Types.ObjectId,
        ref:"user"
    },
    grade: {
        type: String,
        required: true
    },
    subject:{
        type: String,
        required: true
    },
    tags:{
        type: String,
        required: true
    },
    topic:{
        type: String,
        required: true
    },
    alignment:{
        type: String,
        required: true
    },
    name:{
        type: String,
        required: true
    },
    upload:{
        data:Buffer,
        required: true
    }
});
module.exports = mongoose.models['videos'] || mongoose.model('videos', VideoSchema);