const mongoose = require("mongoose");
const {Schema}=mongoose;

const QuestionSchema = new Schema({
    user:{
        type: mongoose.Schema.Types.ObjectId,
        ref:"user"
    },
    description: {
        type: String,
        required: true
    },
    tags: {
        type: String,
        required: true
    },
    date: {
        type: Date,
        default: Date.now
    },
    grade:{
        type: String,
        required: true
    },
    subject:{
        type: String,
        required: true
    },
    topic:{
        type: String,
        required: true
    },
    alignment:{
        type: String,
        required: true
    },
    optionA:{
        type: String,
        required: true
    },
    optionB:{
        type: String,
        required: true
    },
    optionC:{
        type: String,
        required: true
    },
    optionD:{
        type: String,
        required: true
    },
    correctOption:{
        type: String,
        required: true
    },
});
module.exports = mongoose.models['questions'] || mongoose.model('questions', QuestionSchema);