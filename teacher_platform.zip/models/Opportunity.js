const mongoose = require("mongoose");
const {Schema}=mongoose;

const OpportunitySchema = new Schema({
    user:{
        type: mongoose.Schema.Types.ObjectId,
        ref:"user"
    },
    name: {
        type: String,
        required: true
    },
    reward:{
        type: String,
        required: true
    },
    date:{
        type: Date,
        default: Date.now
    },
    expiry:{
        type: Date,
        required: true
    }
});
module.exports = mongoose.models['opportunites'] || mongoose.model('opportunites', OpportunitySchema);