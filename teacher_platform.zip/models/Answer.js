const mongoose = require("mongoose");
const {Schema}=mongoose;

const AnswerSchema = new Schema({
    user:{
        type: mongoose.Schema.Types.ObjectId,
        ref:"user"
    },
    description: {
        type: String
    },
    correctOption:{
        type: String
    },
});
module.exports = mongoose.models['answers'] || mongoose.model('answers', AnswerSchema);