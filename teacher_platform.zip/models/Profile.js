const mongoose = require("mongoose");
const {Schema}=mongoose;

const ProfileSchema = new Schema({
    user:{
        type: mongoose.Schema.Types.ObjectId,
        ref:"user"
    },
    img:{
        data: Buffer,
        contentType: String
    },
    location:{
        type: String,
        required: true
    },
    about:{
        type: String,
        required: true
    },
    dob:{
        type:Date,
        required: true
    },
    phone:{
        type: String,
        required: true
    },
    workTitle:{
        type: String,
        required: true
    },
    workDescription:{
        type: String,
        required: true
    },
    education:{
        type: String,
        required: true
    },
    college:{
        type: String,
        required: true
    },
    collegeStart:{
        type: Date,
        required: true
    },
    collegeEnd:{
        type: Date,
        required: true
    },
    certification:{
        type: String,
        required: true
    },
    certificationIssue:{
        type: Date,
        required: true
    },
    skills:{
        type: Date,
        required: true
    }
});
module.exports = mongoose.models['profiles'] || mongoose.model('profiles', ProfileSchema);